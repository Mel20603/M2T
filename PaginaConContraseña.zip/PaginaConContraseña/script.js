// Validar contraseña en index.html
function checkPassword() {
    var pass = document.getElementById("password").value;
    if (pass === "m2t_dev") {
        window.location.href = "home.html";
    } else {
        document.getElementById("error").textContent = "Contraseña incorrecta";
    }
}

// Mostrar contenido de cada tema en home.html
function showContent(id) {
    document.querySelectorAll('.content').forEach(div => div.style.display = 'none');
    document.getElementById(id).style.display = 'block';
    loadChoice(id);
}

// Guardar respuestas de "Acepto" o "Rechazo"
function saveChoice(topic, choice) {
    localStorage.setItem(topic, choice);
    document.getElementById(topic + "Choice").textContent = "Tu respuesta: " + choice;
}

// Cargar respuesta guardada al abrir home.html
function loadChoice(topic) {
    var savedChoice = localStorage.getItem(topic);
    if (savedChoice) {
        document.getElementById(topic + "Choice").textContent = "Tu respuesta: " + savedChoice;
    }
}